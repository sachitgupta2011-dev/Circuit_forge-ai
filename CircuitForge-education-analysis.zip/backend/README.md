# Local-account snapshot collaboration — private prototype

Each user has a separately provisioned ID and password, stored as salted scrypt hashes. Room owners grant or revoke access to existing user IDs; members can read and publish snapshots, but only owners can manage membership. Revocation removes active members from the room immediately. Random room IDs are not authorization. Origin checks, expiring server-side sessions, logout socket closure, snapshot version conflicts and atomic writes remain in place. This is explicit snapshot sharing, not simultaneous editing, and it is not end-to-end encrypted.

**Not security audited; do not expose as an unrestricted public or multi-tenant service.** This local-account mode lacks password recovery and self-registration, MFA, read-only roles, audited identity integration, persistent audit logging, distributed rate limits, encryption at rest and independent penetration testing. Google/GitHub/Keycloak gateway integration remains untested and is not mapped to these application accounts. Private network/VPN plus TLS and independent security review are still needed.

## Private local setup

Requires Node 20+ and the full release folder. Create unique strong secrets (at least 16 characters; recommend 32 random bytes per user). The utility reads each secret from stdin, not command arguments. Protect the user file and backups; do not put it in the web root, source control, screenshots or public images.

```sh
cd backend
npm ci
export CF_USERS_FILE="$PWD/users.json"
# Enter a separate strong password per user; Bash -s avoids terminal echo.
read -rsp 'Alice password: ' PW; echo
printf '%s' "$PW" | node users.cjs add alice
unset PW
read -rsp 'Bob password: ' PW; echo
printf '%s' "$PW" | node users.cjs add bob
unset PW
export CF_ORIGIN=http://localhost:8787
npm start
```

Open `http://localhost:8787/index.html?studio=1`, then Team workspace. Alice signs in, creates a room, enters `bob` as member ID and grants access. Bob signs in with his own password and joins that room ID. Members may publish snapshots; applying a remote snapshot replaces local work after confirmation, so export a local backup first. Owners can list and revoke members. Revoked connected clients lose room access, and further joins are denied. Changes to the user database are loaded at startup: **restart the server after adding, removing, or rotating accounts** to invalidate all sessions. To rotate a password, stop the server, `node users.cjs remove alice`, then add alice again with a new password; back up the account file before administration.

Old shared-token rooms have no owner or ACL and are deliberately inaccessible in this version. Back them up; no automatic migration is provided. Never delete the original data until a manually reviewed migration has been completed. Back up the entire data directory securely; snapshots are unencrypted at rest. The server listens on localhost by default. Use a properly configured TLS reverse proxy and VPN for remote access, `CF_ORIGIN=https://your-host`, `CF_SECURE_COOKIE=true`, and a private `CF_DATA_DIR`. Proxies must support WebSocket upgrades. With a reverse proxy, the current rate limiter sees the proxy IP rather than individual client IPs; deploy an independently configured edge rate limiter. Sessions are in-memory and disappear on restart.

Run `npm test` for the account, ACL and persistence regression test. Passing it is not a security audit.

## Optional Keycloak OIDC mode

`oidc-server.cjs` is the separate OIDC-backed implementation used by the experimental Docker template. It validates the gateway-forwarded signed Keycloak ID token and uses its subject as the user ID, with owner/viewer/editor roles and local audit-attempt logs. It does not use this document's local account file or shared token. See `../deployment/README.md` for staging, encrypted-volume responsibilities, identity/SMTP setup and important security limits. OIDC and local-account data have incompatible identity formats; no automatic migration is provided. Mock-JWKS tests and the separate disposable Docker staging test do not constitute an independent audit or a production deployment test.
