'use strict';
// Local administrator provisioning. Password is read from stdin, never argv.
const crypto=require('crypto'),fs=require('fs'),path=require('path');
const [action,id]=process.argv.slice(2),file=path.resolve(process.env.CF_USERS_FILE||path.join(__dirname,'users.json'));
if(!['add','remove'].includes(action)||!/^[a-z0-9][a-z0-9_.-]{2,63}$/.test(id||'')){console.error('Usage: node users.cjs add|remove USER_ID (password on stdin for add)');process.exit(2)}
let data={};if(fs.existsSync(file)){data=JSON.parse(fs.readFileSync(file,'utf8'));if(!data||typeof data!=='object'||Array.isArray(data))throw Error('Invalid account file')}
if(action==='add'){if(Object.hasOwn(data,id))throw Error('User already exists; remove first to rotate credentials');let password=fs.readFileSync(0,'utf8').replace(/\r?\n$/,'');if(password.length<16||password.length>1024)throw Error('Password must be 16–1024 characters; use a unique random secret');const salt=crypto.randomBytes(16).toString('hex'),hash=crypto.scryptSync(password,Buffer.from(salt,'hex'),32).toString('hex');data[id]={salt,hash};}else{if(!Object.hasOwn(data,id))throw Error('Unknown user');delete data[id]}
fs.mkdirSync(path.dirname(file),{recursive:true,mode:0o700});let tmp=file+'.'+crypto.randomBytes(8).toString('hex')+'.tmp';fs.writeFileSync(tmp,JSON.stringify(data,null,2)+'\n',{mode:0o600,flag:'wx'});fs.renameSync(tmp,file);console.log(`${action==='add'?'Added':'Removed'} ${id}; restart server to invalidate active sessions.`);
