# Optional ngspice runner

The website's built-in engine remains a simplified educational solver. This optional helper runs an **independently installed** ngspice on your own computer for decks and supported vendor models. It is not called by the browser site and does not make the website fully SPICE-compatible.

1. Install ngspice and Python 3 on your computer.
2. Use a SPICE deck and vendor model you trust. Check manufacturer license, simulator compatibility, revision, pinout, model limitations and physical measurements.
3. Run `python3 tools/run_ngspice.py path/to/deck.cir --out results` from the extracted release folder. Includes are resolved relative to the deck.
4. Inspect `results/ngspice.log` and, if generated, `results/result.raw` using a compatible waveform viewer.

**Security:** SPICE decks and control commands can access local files or execute external commands. Never run untrusted decks or model files. This helper does not sandbox ngspice. It is not a manufacturer-model verification or fabrication approval.

# KiCad multilayer fabrication draft helper

`kicad_release.py` uses a separately installed KiCad to refill zones, run DRC, and create multilayer Gerber/drill drafts only if KiCad reports no violations or unconnected items. It does not route the board or implement a PCB editor in the browser.

1. Export an editable main-workspace PCB draft from CircuitForge. The Platform Studio planner is separate and is **not** exported to it.
2. In KiCad, finish the routing and layer stackup, verify actual component footprints and hole plating, save the matching `.kicad_pro` with fabricator-specific rules, and perform schematic/ERC checks. Add and configure zones as appropriate.
3. Run with the Python interpreter that can import KiCad's `pcbnew` module. On Debian-style Linux:

   `/usr/bin/python3 tools/kicad_release.py /path/to/board.kicad_pcb --out /path/to/new-output-folder`

   The destination must not already exist. The tool copies the board, matching `.kicad_pro`, and optional `.kicad_dru`; refills zones; runs `kicad-cli pcb drc` in strict mode; and exports copper/mask/silkscreen/outline plus separated PTH/NPTH drill files only on a clean report. If no `.kicad_pro` exists it refuses by default. `--allow-default-rules` is for demonstrations only, not a substitute for fab requirements.
4. Inspect the generated Gerbers and drills in independent CAM software, verify layer order, clearances, stackup, finish, holes and board dimensions with the fabricator, and review electrical/schematic parity. KiCad DRC passing does not certify the design.

Tested with KiCad 9.0.2 and Gerbv 2.10.0. An empty 4-layer board passed and was exported; the CircuitForge starter board had DRC and unconnected-net findings and was correctly blocked. The tool is a fail-closed assistance workflow, not a production guarantee. `tests/kicad-check.py` reruns these fixtures with KiCad's Python.
