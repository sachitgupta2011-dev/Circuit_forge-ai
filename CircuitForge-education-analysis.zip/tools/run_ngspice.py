#!/usr/bin/env python3
"""Optional local ngspice bridge. Run only SPICE decks and model files you trust."""
import argparse,pathlib,shutil,subprocess,sys
p=argparse.ArgumentParser(description='Run a trusted SPICE deck using a separately installed ngspice. This does not integrate ngspice into the browser app.')
p.add_argument('deck',type=pathlib.Path,help='Path to a trusted SPICE deck; relative includes are resolved from its folder')
p.add_argument('--out',type=pathlib.Path,default=pathlib.Path('ngspice-output'),help='Output directory for log and raw results')
a=p.parse_args();exe=shutil.which('ngspice')
if not exe:sys.exit('ngspice not found. Install ngspice first and ensure it is on PATH.')
deck=a.deck.resolve();out=a.out.resolve()
if not deck.is_file():sys.exit('Deck not found: '+str(deck))
out.mkdir(parents=True,exist_ok=True);log=out/'ngspice.log';raw=out/'result.raw'
if raw.exists():raw.unlink()
print('Run trusted input only: ngspice control commands and includes may access local files.')
r=subprocess.run([exe,'-b','-r',str(raw),'-o',str(log),str(deck)],cwd=deck.parent,check=False)
print('ngspice exit code:',r.returncode,'\nLog:',log)
if log.exists():
 text=log.read_text(errors='replace');print(text[-4000:])
 if any(x in text.lower() for x in ('error:', 'fatal error', 'simulation(s) aborted', 'no simulations run')):print('Inspect reported errors; results must not be treated as valid.',file=sys.stderr);sys.exit(1)
if raw.exists() and raw.stat().st_size:print('Raw results:',raw)
else:print('No raw results were written. Inspect the log; control scripts may use their own outputs.')
sys.exit(r.returncode)
