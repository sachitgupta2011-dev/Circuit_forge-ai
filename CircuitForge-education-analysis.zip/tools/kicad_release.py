#!/usr/bin/env python3
"""Create a KiCad-checked Gerber draft from a trusted .kicad_pcb file.
Requires KiCad pcbnew Python bindings, kicad-cli and Python 3. This tool never modifies the input.
"""
import argparse,hashlib,json,os,pathlib,shutil,subprocess,sys
p=argparse.ArgumentParser(description='Refill and DRC a KiCad board; export Gerber/drill only when DRC passes. This is NOT fabrication certification.')
p.add_argument('board',type=pathlib.Path,help='Trusted editable .kicad_pcb file, completed in KiCad')
p.add_argument('--out',required=True,type=pathlib.Path,help='NEW output directory; cannot already exist')
p.add_argument('--allow-default-rules',action='store_true',help='Permit a board without a .kicad_pro file (demonstration only; default rules may not match the fabricator)')
a=p.parse_args();source=a.board.resolve();out=a.out.resolve();project=source.with_suffix('.kicad_pro');cli=shutil.which('kicad-cli')
if not cli:sys.exit('kicad-cli not found. Install KiCad and add kicad-cli to PATH.')
try: import pcbnew
except ImportError:sys.exit('KiCad pcbnew Python bindings not available. Use the Python interpreter supplied with KiCad (often /usr/bin/python3 on Linux).')
if not source.is_file() or source.suffix.lower()!='.kicad_pcb':sys.exit('Provide an existing .kicad_pcb file.')
if not project.is_file() and not a.allow_default_rules:sys.exit('No matching .kicad_pro file. Configure fabricator-specific rules in KiCad and save the project; --allow-default-rules is for demonstrations only.')
try:out.mkdir(parents=True,exist_ok=False)
except FileExistsError:sys.exit('Output directory already exists; choose a new directory to avoid overwriting files.')
boardpath=out/'board.kicad_pcb';shutil.copy2(source,boardpath)
if project.is_file():shutil.copy2(project,out/'board.kicad_pro')
rules=source.with_suffix('.kicad_dru')
if rules.is_file():shutil.copy2(rules,out/'board.kicad_dru')
try:
 board=pcbnew.LoadBoard(str(boardpath));layers=board.GetCopperLayerCount()
 if layers<2 or layers>32 or layers%2:raise ValueError(f'Unsupported copper layer count: {layers}')
 print('Refilling zones with KiCad:',pcbnew.Version(),'layers:',layers)
 if not pcbnew.ZONE_FILLER(board).Fill(board.Zones()):raise RuntimeError('KiCad zone refill failed')
 if not pcbnew.SaveBoard(str(boardpath),board):raise RuntimeError('Could not save refilled board')
except Exception as e:sys.exit('Refill failed; no Gerbers generated: '+str(e))
def run(args):
 print('+',' '.join(args));r=subprocess.run(args,text=True,capture_output=True);print(r.stdout,end='');print(r.stderr,end='',file=sys.stderr);return r.returncode
report=out/'drc.json';rc=run([cli,'pcb','drc','--format','json','--severity-all','--exit-code-violations','-o',str(report),str(boardpath)])
if rc!=0:sys.exit(f'DRC reported violations or failed (exit {rc}). Inspect {report}; no Gerbers generated.')
try:
 drc=json.loads(report.read_text());violations=drc.get('violations',[]);unconnected=drc.get('unconnected_items',[])
 if violations or unconnected:sys.exit('DRC report is not clean; no Gerbers generated.')
except (OSError,ValueError,TypeError) as e:sys.exit('Could not validate DRC report; no Gerbers generated: '+str(e))
layer_names=['F.Cu']+[f'In{i}.Cu' for i in range(1,layers-1)]+['B.Cu','F.Mask','B.Mask','F.Silkscreen','B.Silkscreen','Edge.Cuts']
fab=out/'gerbers';fab.mkdir();rc=run([cli,'pcb','export','gerbers','-l',','.join(layer_names),'-o',str(fab),str(boardpath)])
if rc!=0:sys.exit('Gerber export failed; delete or quarantine the output directory.')
rc=run([cli,'pcb','export','drill','--format','excellon','--excellon-units','mm','--excellon-separate-th','-o',str(fab),str(boardpath)])
if rc!=0:sys.exit('Drill export failed; delete or quarantine the output directory.')
manifest={'kicad_version':pcbnew.Version(),'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'copper_layers':layers,'project_rules':project.is_file(),'custom_rules_file':rules.is_file(),'files':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(fab.iterdir()) if f.is_file()},'warning':'KiCad DRC passing is not manufacturing approval. Verify schematic parity, stackup, footprints, hole plating, clearances, zone connectivity, Gerbers and drills independently with CAM and the fabricator.'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('DRC passed and draft files generated:',fab);print(manifest['warning'])
