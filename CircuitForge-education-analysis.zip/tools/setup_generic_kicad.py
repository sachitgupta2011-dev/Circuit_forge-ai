#!/usr/bin/env python3
"""Create editable generic KiCad settings alongside a trusted board; never overwrite."""
import argparse,pathlib,shutil,sys
p=argparse.ArgumentParser(description='Create an editable generic KiCad baseline. Not a fabricator specification.')
p.add_argument('board',type=pathlib.Path);a=p.parse_args();board=a.board.resolve()
if not board.is_file() or board.suffix.lower()!='.kicad_pcb':sys.exit('Provide an existing .kicad_pcb file.')
root=pathlib.Path(__file__).resolve().parents[1]; pairs=[(root/'templates/generic.kicad_pro',board.with_suffix('.kicad_pro')),(root/'templates/generic.kicad_dru',board.with_suffix('.kicad_dru'))]
if any(dst.exists() for _,dst in pairs):sys.exit('A project or rules file already exists; nothing overwritten.')
for src,dst in pairs:shutil.copyfile(src,dst);print('Created:',dst)
print('Generic editable baseline only. Review and change all rules to match your fabricator and design.')
