#!/usr/bin/env python3
"""KiCad integration smoke test. Requires kicad-cli, KiCad's pcbnew Python bindings and gerbv."""
import pathlib,subprocess,sys,tempfile
root=pathlib.Path(__file__).resolve().parents[1];script=root/'tools/kicad_release.py';fixtures=root/'verification'
with tempfile.TemporaryDirectory() as d:
 d=pathlib.Path(d)
 def run(board,out):return subprocess.run([sys.executable,str(script),str(board),'--out',str(out),'--allow-default-rules'],capture_output=True,text=True)
 clean=run(fixtures/'kicad-empty-four-layer.kicad_pcb',d/'clean')
 assert clean.returncode==0,(clean.stdout,clean.stderr)
 out=d/'clean'/'gerbers'
 for pattern in ('*In1_Cu*','*In2_Cu*','*Edge_Cuts*','*PTH.drl','*NPTH.drl'):assert list(out.glob(pattern)),pattern
 for f in out.glob('*.g*'):
  if f.suffix=='.gbrjob':continue
  r=subprocess.run(['gerbv','-x','svg','-o',str(d/'out.svg'),str(f)],capture_output=True,text=True);assert r.returncode==0,(f,r.stderr)
 print('PASS: KiCad 4-layer empty-board refill, DRC, Gerber/drill output and Gerbv parse')
 bad=run(fixtures/'kicad-starter-four-layer.kicad_pcb',d/'bad')
 assert bad.returncode!=0 and (d/'bad'/'drc.json').exists() and not (d/'bad'/'gerbers').exists(),(bad.stdout,bad.stderr)
 print('PASS: incomplete starter board blocked on independent KiCad DRC')
with tempfile.TemporaryDirectory() as d:
 d=pathlib.Path(d); board=d/'narrow.kicad_pcb'; board.write_bytes((fixtures/'kicad-narrow-track.kicad_pcb').read_bytes())
 setup=root/'tools/setup_generic_kicad.py'
 cmd=[sys.executable,str(setup),str(board)]
 r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,(r.stdout,r.stderr)
 pro=board.with_suffix('.kicad_pro'); rules=board.with_suffix('.kicad_dru'); before=(pro.read_bytes(),rules.read_bytes())
 assert subprocess.run(cmd,capture_output=True).returncode!=0 and before==(pro.read_bytes(),rules.read_bytes())
 result=subprocess.run([sys.executable,str(script),str(board),'--out',str(d/'blocked')],capture_output=True,text=True)
 assert result.returncode!=0 and (d/'blocked'/'drc.json').exists() and not (d/'blocked'/'gerbers').exists(),(result.stdout,result.stderr)
 assert 'track_width' in (d/'blocked'/'drc.json').read_text().lower()
 print('PASS: generic project setup, no overwrite, and 0.22 mm track blocked by 0.25 mm rule')
print('These are smoke tests, not fabrication certification.')
