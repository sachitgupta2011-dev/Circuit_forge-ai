#!/usr/bin/env python3
"""Compare captured browser fixture data against ngspice, and render example Gerbers in Gerbv."""
import bisect,json,math,pathlib,subprocess,tempfile,re
root=pathlib.Path(__file__).resolve().parents[1]
r=json.loads((root/'verification/reference-browser-output.json').read_text())
networks={'rc':'R1 in out 1k\nC1 out 0 1u','rl':'L1 in out 1m\nR1 out 0 1','rlc':'R1 in n 10\nL1 n out 1m\nC1 out 0 1u'}
with tempfile.TemporaryDirectory() as d:
 d=pathlib.Path(d)
 for name,network in networks.items():
  step,end=('1u','1m') if name=='rlc' else ('10u','4m')
  deck=f'''{name} reference\nV1 in 0 PULSE(0 5 0 1n 1n 10m 20m)\n{network}\n.control\nset noaskquit\ntran {step} {end}\nwrdata {d/'out.dat'} v(out)\nquit\n.endc\n.end\n'''
  (d/'test.cir').write_text(deck);subprocess.run(['ngspice','-b',str(d/'test.cir')],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  dat=[list(map(float,l.split())) for l in (d/'out.dat').read_text().splitlines()];times=[x[0] for x in dat];err=[]
  for t,v in zip(r[name]['result']['times'],r[name]['result']['wave']['out']):
   i=bisect.bisect_left(times,t)
   if i==0: ref=dat[0][1]
   elif i==len(times): ref=dat[-1][1]
   else:
    a,b=dat[i-1],dat[i];ref=a[1]+(b[1]-a[1])*(t-a[0])/(b[0]-a[0])
   err.append(abs(v-ref))
  mx=max(err);assert mx<.08,(name,mx);print(f'PASS {name} vs ngspice: max {mx:.6f} V')
 # Sinusoidal drive through RC, checks SPICE SIN argument order and transient waveform.
 sine=json.loads((root/'verification/sin-browser-output.json').read_text())['result']
 deck=f"""Sine RC reference\nV1 in 0 SIN(0 1 1k 0 0 0)\nR1 in out 1k\nC1 out 0 100n\n.control\ntran 2u 2m\nwrdata {d/'sin.dat'} v(out)\nquit\n.endc\n.end\n"""
 (d/'test.cir').write_text(deck);subprocess.run(['ngspice','-b',str(d/'test.cir')],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 dat=[list(map(float,l.split())) for l in (d/'sin.dat').read_text().splitlines()];times=[x[0] for x in dat];err=[]
 for t,v in zip(sine['times'],sine['wave']['out']):
  i=bisect.bisect_left(times,t)
  if i==0:ref=dat[0][1]
  elif i==len(times):ref=dat[-1][1]
  else:
   a,b=dat[i-1],dat[i];ref=a[1]+(b[1]-a[1])*(t-a[0])/(b[0]-a[0])
  err.append(abs(v-ref))
 mx=max(err);assert mx<.012,mx;print(f'PASS sinusoidal RC transient vs ngspice: max {mx:.6f} V')
 deck=f'''AC low pass\nV1 in 0 AC 1\nR1 in out 1k\nC1 out 0 159.154943n\n.control\nset noaskquit\nac dec 10 100 10k\nwrdata {d/'ac.dat'} v(out)\nquit\n.endc\n.end\n'''
 (d/'test.cir').write_text(deck);subprocess.run(['ngspice','-b',str(d/'test.cir')],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 dat=[list(map(float,l.split())) for l in (d/'ac.dat').read_text().splitlines()];ac=r['ac']['result']['results'];assert len(dat)==len(ac)
 err=max(abs(complex(x['voltages']['out']['re'],x['voltages']['out']['im'])-complex(row[1],row[2])) for x,row in zip(ac,dat));assert err<1e-6,err;print(f'PASS AC vs ngspice: max complex error {err:.3g} V')
 extras=json.loads((root/'verification/ac-extra-browser-output.json').read_text())
 for name,fixture in extras.items():
  # ngspice skips the appended non-grid endpoint; compare common frequencies only.
  deck=fixture['deck'];analysis=re.search(r'^\.ac .+$',deck,re.M).group(0)[1:]
  deck=re.sub(r'^\.ac .+$',f'.control\nset noaskquit\n{analysis}\nwrdata {d/"ac2.dat"} v(out)\nquit\n.endc',deck,flags=re.M)
  (d/'extra-ac.cir').write_text(deck);subprocess.run(['ngspice','-b',str(d/'extra-ac.cir')],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  reference=[list(map(float,l.split())) for l in (d/'ac2.dat').read_text().splitlines()]
  browser=fixture['result']['result']['results'];errors=[]
  for row in reference:
   a=min(browser,key=lambda x:abs(x['f']-row[0]));assert abs(a['f']-row[0])/row[0]<1e-6
   v=a['voltages']['out'];errors.append(abs(complex(v['re'],v['im'])-complex(row[1],row[2])))
  err=max(errors);assert err<1e-6,(name,err);print(f'PASS {name} AC vs ngspice: {len(reference)} points, max complex error {err:.3g} V')
 # Four limited level-1 nonlinear DC fixtures; models are synthetic, not vendor-qualified.
 fixtures=json.loads((root/'verification/nonlinear-browser-output.json').read_text())
 import re
 for name,fixture in fixtures.items():
  node='c' if name in ('npn','pnp') else 'd'
  deck=fixture['deck'].replace('.op\n.end',f'.control\nop\nprint v({node})\nquit\n.endc\n.end')
  (d/'nonlinear.cir').write_text(deck)
  result=subprocess.run(['ngspice','-b',str(d/'nonlinear.cir')],check=True,capture_output=True,text=True)
  m=re.search(r'v\('+node+r'\)\s*=\s*([-+0-9.eE]+)',result.stdout,re.I);assert m,(name,result.stdout,result.stderr)
  browser=fixture['result']['result']['voltages'][node];ref=float(m.group(1));diff=abs(browser-ref)
  assert diff<0.001,(name,browser,ref)
  print(f'PASS {name} synthetic DC fixture vs ngspice: delta {diff:.6g} V')
 fix=root/'verification/gerber-fixture'
 for name in ['F_Cu.gtl','B_Cu.gbl','F_Mask.gts','B_Mask.gbs','F_Silkscreen.gto','Edge_Cuts.gm1','drill.drl']:
  output=d/(name+'.svg');p=subprocess.run(['gerbv','-x','svg','-o',str(output),str(fix/name)],capture_output=True,text=True)
  assert p.returncode==0 and output.exists() and output.stat().st_size>0,(name,p.stderr)
  print('PASS Gerbv parsed and rendered',name)
print('These fixture checks do not constitute production manufacturing approval.')
