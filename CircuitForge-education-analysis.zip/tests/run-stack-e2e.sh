#!/usr/bin/env bash
# Disposable LOCAL test only. NEVER point this at real services or existing data.
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
if docker compose version >/dev/null 2>&1; then DC=(docker compose); elif command -v docker-compose >/dev/null; then DC=(docker-compose); else echo 'Docker Compose v2 is required.' >&2; exit 2; fi
command -v openssl >/dev/null; command -v python3 >/dev/null
T=$(mktemp -d "${TMPDIR:-/tmp}/cf-staging-XXXXXXXX")
PROJECT="cfstage$(openssl rand -hex 4)"
chmod 0755 "$T"
compose(){ "${DC[@]}" --env-file "$T/.env" -f "$ROOT/deployment/compose.yaml" -f "$T/override.yaml" -f "$T/ports.yaml" -p "$PROJECT" "$@"; }
cleanup(){ compose down -v --remove-orphans >/dev/null 2>&1 || true; rm -rf "$T"; }
trap cleanup EXIT
mkdir -p "$T"/{app,postgres,caddy-data,caddy-config}; chmod 0777 "$T/app"
SECRET=$(openssl rand -hex 24); COOKIE=$(python3 -c 'import base64,os; print(base64.urlsafe_b64encode(os.urandom(32)).decode())')
cat > "$T/.env" <<ENV
CF_DATA_ROOT=$T
APP_HOST=app.cf.test:9443
AUTH_HOST=auth.cf.test:9443
OIDC_CLIENT_ID=circuitforge-gateway
OIDC_CLIENT_SECRET=$SECRET
POSTGRES_PASSWORD=$SECRET
KC_ADMIN_USER=admin
KC_ADMIN_PASSWORD=$SECRET
OAUTH_COOKIE_SECRET=$COOKIE
SMTP_HOST=mail
SMTP_PORT=1025
SMTP_FROM=noreply@cf.test
SMTP_USER=unused
SMTP_PASSWORD=unused
ENV
chmod 0600 "$T/.env"
openssl req -x509 -newkey rsa:2048 -nodes -keyout "$T/ca.key" -out "$T/ca.crt" -days 2 -subj '/CN=CircuitForge staging CA' >/dev/null 2>&1
openssl req -newkey rsa:2048 -nodes -keyout "$T/server.key" -out "$T/server.csr" -subj '/CN=app.cf.test' >/dev/null 2>&1
printf 'subjectAltName=DNS:app.cf.test,DNS:auth.cf.test\nextendedKeyUsage=serverAuth\n' > "$T/ext.cnf"
openssl x509 -req -in "$T/server.csr" -CA "$T/ca.crt" -CAkey "$T/ca.key" -CAcreateserial -out "$T/server.crt" -days 2 -extfile "$T/ext.cnf" >/dev/null 2>&1
chmod 0644 "$T/ca.crt" "$T/server.crt"
chmod 0600 "$T/server.key"
cat > "$T/Caddyfile" <<'CADDY'
https://app.cf.test:9443 {
 tls /certs/server.crt /certs/server.key
 reverse_proxy login-gateway:4180
}
https://auth.cf.test:9443 {
 tls /certs/server.crt /certs/server.key
 reverse_proxy identity:8080
}
CADDY
python3 - "$ROOT/deployment/realm-import.json" "$T/realm.json" <<'PY'
import json,sys
j=json.load(open(sys.argv[1]));j['smtpServer']={'host':'mail','port':'1025','from':'noreply@cf.test','auth':'false','starttls':'false'}
with open(sys.argv[2],'w') as f: json.dump(j,f)
PY
cat > "$T/override.yaml" <<YAML
services:
  app:
    environment: { NODE_EXTRA_CA_CERTS: /certs/ca.crt }
    volumes: ["$T:/certs:ro"]
  identity:
    environment: { KC_TRUSTSTORE_PATHS: /certs/ca.crt }
    volumes: ["$T:/certs:ro", "$T/realm.json:/opt/keycloak/data/import/circuitforge-realm.json:ro"]
  login-gateway:
    environment: { SSL_CERT_FILE: /certs/ca.crt }
    volumes: ["$T:/certs:ro"]
  proxy:
    ports: !reset []
    volumes: ["$T/Caddyfile:/etc/caddy/Caddyfile:ro", "$T:/certs:ro"]
    networks:
      private:
        aliases: [auth.cf.test, app.cf.test]
  mail:
    image: axllent/mailpit:v1.21.8
    networks: [private]
    ports: ["127.0.0.1:18025:8025"]
YAML
printf 'services:\n  proxy:\n    ports: ["127.0.0.1:9443:9443"]\n' > "$T/ports.yaml"
compose up -d --build
# Wait for both real issuer and gateway; bounded to three minutes.
if ! python3 - <<'PY'
import subprocess,time,sys
for _ in range(90):
 r=subprocess.run(['curl','--noproxy','*','-sk','--resolve','app.cf.test:9443:127.0.0.1','-o','/dev/null','-w','%{http_code}','https://app.cf.test:9443/oauth2/sign_in'],capture_output=True,text=True)
 if r.stdout=='200':break
 time.sleep(2)
else: print('Gateway did not start within 3 minutes',file=sys.stderr);sys.exit(1)
PY
then compose logs --tail 20 identity login-gateway proxy app >&2; exit 1; fi
(cd "$ROOT/tests" && node stack-e2e.cjs)
echo 'Staging services stopped and temporary data removed on exit.'
