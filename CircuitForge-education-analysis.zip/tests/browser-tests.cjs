const {chromium}=require('playwright');
const {spawn}=require('child_process');const assert=require('assert');const path=require('path');
const root=path.resolve(__dirname,'..');const server=spawn('python3',['-m','http.server','8765','--bind','127.0.0.1'],{cwd:root,stdio:'ignore'});
const approx=(a,b,t,msg)=>assert(Math.abs(a-b)<=t,`${msg}: ${a} vs ${b} ± ${t}`);
(async()=>{let b;try{
 await new Promise(r=>setTimeout(r,1000));b=await chromium.launch({headless:true});const c=await b.newContext(),p=await c.newPage();const errors=[];p.on('pageerror',e=>errors.push(e.message));
 await p.goto('http://127.0.0.1:8765/index.html?section=lab');
 const lessons=await p.evaluate(()=>[...document.querySelector('#templateSelect').options].map(o=>o.value).filter(Boolean).map(id=>{try{LearnPortal.loadTemplate(id,true);let a=LearnPortal.solve();return {id,parts:LearnPortal.state.components.length,wires:LearnPortal.state.wires.length,ok:a.ok};}catch(e){return {id,error:e.message}}}));
 assert.equal(lessons.length,10);for(const l of lessons)assert(l.ok&&l.parts>0&&l.wires>0,JSON.stringify(l));console.log('PASS: all 10 lesson templates load and solve');
 await p.locator('#cfpuRevBtn').click();await p.locator('#cfpuRevMark').click();assert(await p.locator('[data-rev-restore]').count());await p.locator('[data-rev-restore]').first().click();console.log('PASS: Learn version snapshot and restore');
 await p.goto('http://127.0.0.1:8765/index.html?studio=1');
 const results=await p.evaluate(()=>{const E=window.CFSpiceEngine;const decks={rc:'* RC\nV1 in 0 PULSE(0 5 0 1n 1n 10m 20m)\nR1 in out 1k\nC1 out 0 1u\n.tran 10u 4m\n.end',rl:'* RL\nV1 in 0 PULSE(0 5 0 1n 1n 10m 20m)\nL1 in out 1m\nR1 out 0 1\n.tran 10u 4m\n.end',rlc:'* RLC\nV1 in 0 PULSE(0 5 0 1n 1n 10m 20m)\nR1 in n 10\nL1 n out 1m\nC1 out 0 1u\n.tran 1u 1m\n.end',ac:'* AC\nV1 in 0 AC 1\nR1 in out 1k\nC1 out 0 159.154943n\n.ac dec 10 100 10k\n.end',iac:'* AC current\nI1 out 0 AC 1 90\nR1 out 0 1k\n.ac lin 1 100 100\n.end',vccs:'* VCCS\nV1 in 0 AC 1\nG1 out 0 in 0 0.001\nR1 out 0 1k\n.ac lin 1 100 100\n.end'};let o={reg:E.runRegression()};for(const [k,v] of Object.entries(decks))o[k]=E.runDeck(v).results[0];return o});
 for(const r of results.reg)assert(r.pass,JSON.stringify(r));console.log('PASS: '+results.reg.length+' existing SPICE regression cases');
 for(const key of ['rc','rl','rlc','ac','iac','vccs'])assert(!results[key].error,`${key}: ${results[key].error}`);
 for(const key of ['rc','rl']){let w=results[key].result;let i=w.times.findIndex(t=>t>=0.001-1e-10);approx(w.wave.out[i],5*(1-Math.exp(-1)),0.04,key+' transient');}
 {let w=results.rlc.result;let i=w.times.findIndex(t=>t>=0.0001-1e-10),alpha=5000,wd=Math.sqrt(1e9-alpha**2);let expected=5*(1-Math.exp(-alpha*0.0001)*(Math.cos(wd*0.0001)+alpha/wd*Math.sin(wd*0.0001)));approx(w.wave.out[i],expected,.08,'RLC transient');}
 let ac=results.ac.result;let i=ac.freqs.findIndex(f=>Math.abs(f-1000)<.01),v=ac.results[i].voltages.out;approx(20*Math.log10(Math.hypot(v.re,v.im)),-3.0103,.01,'RC Bode dB');approx(Math.atan2(v.im,v.re)*180/Math.PI,-45,.02,'RC Bode phase');
 v=results.iac.result.results[0].voltages.out;approx(v.im,-1000,.001,'AC current phase');v=results.vccs.result.results[0].voltages.out;approx(v.re,-1,.001,'VCCS AC');console.log('PASS: RC/RL/RLC transient; AC magnitude, phase, current source and VCCS');
 const safeguards=await p.evaluate(()=>{
  const E=CFSpiceEngine;const dc=E.runDeck('* current source\nI1 out 0 DC 1\nR1 out 0 1k\n.op\n.end').results[0];
  const model=E.parseNetlist('* parenthesized model\n.model mn NMOS(VTO=2 KP=50u\n+ LAMBDA=0.01 RD=1)\n.end');
  let include=false;try{E.runDeck('* external\n.include vendor.lib\n.op\n.end')}catch(e){include=/External model/.test(e.message)}
  const rejected=E.runMonteCarlo('* nonlinear\nV1 in 0 DC 5\nD1 in 0 dm\n.model dm D(IS=1e-14)\n.op\n.end',{runs:5});
  const pcb=ensurePCB(), old=pcb.layers,oldPour=pcb.pour;pcb.layers=2;pcb.pour=true;const noUnsafeFill=!gerberFiles()['F_Cu.gtl'].includes('G36*');pcb.layers=4;let blocked=false;try{gerberFiles()}catch(e){blocked=/Multilayer Gerber export is disabled/.test(e.message)}pcb.layers=old;pcb.pour=oldPour;
  return {v:dc.result.voltages.out,model:model.models.mn,warnings:model.warnings,include,rejected:rejected.error,noUnsafeFill,blocked};
 });
 approx(safeguards.v,-1000,.001,'DC current polarity');assert.equal(safeguards.model.VT,2);approx(safeguards.model.LAMBDA,.01,1e-12,'continuation model');assert(safeguards.warnings.some(w=>w.includes('RD')));assert(safeguards.include&&safeguards.rejected&&safeguards.noUnsafeFill&&safeguards.blocked);console.log('PASS: model warnings, nonlinear tolerance guard, current polarity and PCB export safeguards');
 const deep=await p.evaluate(()=>{
  const E=CFSpiceEngine, failures=[];
  for(let a=1;a<=10;a++)for(let b=1;b<=10;b++){const r1=a*100,r2=b*100,deck=`* divider\nV1 in 0 DC 5\nR1 in out ${r1}\nR2 out 0 ${r2}\n.op\n.end`;const r=E.runDeck(deck).results[0];if(r.error||Math.abs(r.result.voltages.out-5*r2/(r1+r2))>1e-6)failures.push([a,b]);}
  const model=E.parseNetlist('* source\nV1 in 0 DC 2m AC 3m 90\nV2 x 0 SIN(0 1 1k 0 0 0)\n.end');
  const board={w:50,h:50,clearance:0.25,shape:'rect',traces:[{net:'A',layer:'F',w:.2,pts:[[5,10],[20,10]]}],vias:[{net:'B',x:10,y:10,d:1,drill:.4}],netRules:{}};
  const audit=window.CircuitForgeClearanceAudit.audit, short=audit(board,[]), ok=audit({...board,vias:[{...board.vias[0],net:'A'}]},[]), edge=audit({...board,traces:[{net:'A',layer:'F',w:.2,pts:[[.05,1],[5,1]]}],vias:[]},[]);
  const pads=[{x:5,y:5,d:1,net:'A',c:'A',pin:'1',smd:true,side:'T'},{x:5,y:5,d:1,net:'B',c:'B',pin:'1',smd:true,side:'B'}];
  const opposites=audit({...board,traces:[],vias:[]},pads),sameSide=audit({...board,traces:[],vias:[]},[pads[0],{...pads[1],side:'T'}]);
  return {failures,dc:model.elements[0].dc,ac:model.elements[0].acmag,phase:model.elements[0].acphase,sin:E.srcValue(model.elements[1],.00025),short:short.length,ok:ok.length,edge:edge.length,opposites:opposites.length,sameSide:sameSide.length};
 });
 assert.deepEqual(deep.failures,[]);approx(deep.dc,.002,1e-12,'source dc suffix');approx(deep.ac,.003,1e-12,'source AC suffix');approx(deep.phase,90,1e-12,'source phase');approx(deep.sin,1,1e-12,'SIN order');assert(deep.short>0&&deep.ok===0&&deep.edge>0&&deep.opposites===0&&deep.sameSide>0);console.log('PASS: 100 DC divider cases, source parsing and geometry edge/short/layer checks');
 const integrated=await p.evaluate(()=>{const pcb=ensurePCB(),oldTraces=pcb.traces,oldVias=pcb.vias;try{const nets=pcbNets().nets;pcb.traces=[{net:nets[0].name,layer:'F',w:.2,pts:[[10,10],[20,10]]}];pcb.vias=[{net:nets[1].name,x:15,y:10,d:1,drill:.4}];return pcbDRC(true).some(x=>x.m.includes('Supplemental DRC')&&x.m.includes('via 0 and trace 0'));}finally{pcb.traces=oldTraces;pcb.vias=oldVias;}});assert(integrated);console.log('PASS: supplemental clearance audit integrated into PCB DRC');
 await p.locator('#cfPlatformBtn').click();
 await p.locator('#cfPSDeck').fill('* AC test\nV1 in 0 AC 1\nR1 in out 1k\nC1 out 0 159.154943n\n.ac dec 10 100 10k\n.end');
 await p.locator('#cfPSParse').click();await p.locator('[data-bode-ref]').waitFor();await p.locator('[data-bode-node]').selectOption('out');await p.locator('[data-bode-ref]').selectOption('in');console.log('PASS: Bode output/reference controls');
 await p.locator('#cfPSDeck').fill('* divider\nV1 in 0 DC 5\nR1 in out 1k\nR2 out 0 1k\n.op\n.end');
 assert.equal(await p.locator('#cfPlatformShade').getByText('▶ Run Monte Carlo').count(),1);await p.locator('#cfPlatformShade').getByText('▶ Run Monte Carlo').click();await p.locator('#cfSpiceMCPanelPS [data-control=cfspMCResult]').getByText('50 runs completed.').waitFor();console.log('PASS: Monte Carlo UI');
 await p.getByRole('button',{name:'Multi-layer PCB'}).click();await p.locator('#cfKiCadDraft').waitFor();p.once('dialog',d=>d.accept());const downloading=p.waitForEvent('download');await p.locator('#cfKiCadDraft').click();const download=await downloading;assert.equal(download.suggestedFilename(),'circuitforge-draft.kicad_pcb');console.log('PASS: editable KiCad draft download');
 assert.deepEqual(errors,[]);console.log('PASS: no page errors during test flows');
 }catch(e){console.error('FAIL:',e.stack);process.exitCode=1}finally{if(b)await b.close();server.kill();}})();
