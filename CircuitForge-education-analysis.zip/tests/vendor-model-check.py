#!/usr/bin/env python3
"""Check one manufacturer-hosted 1N4148W file against its recorded SHA-256 and one datasheet bound using ngspice.
Run only model files you trust: ngspice is not sandboxed.
"""
import argparse,hashlib,pathlib,re,subprocess,sys,tempfile
p=argparse.ArgumentParser(description='One-point check, NOT comprehensive manufacturer-model verification')
p.add_argument('model',type=pathlib.Path,help='Trusted manufacturer 1N4148W.spice.txt downloaded separately')
a=p.parse_args();data=a.model.read_bytes();digest=hashlib.sha256(data).hexdigest();expected='eac112ab3b235eb9f54916f7f9d793ba15091a1fb6988e4eef5652aad393437a'
print('SHA-256:',digest)
if digest!=expected:sys.exit('Checksum does not match the recorded manufacturer download. Review any revision/change before running.')
with tempfile.TemporaryDirectory() as td:
 d=pathlib.Path(td);(d/'model.lib').write_bytes(data)
 (d/'check.cir').write_text('Manufacturer model one-point check\n.include model.lib\nI1 0 out DC 1m\nD1 out 0 1N4148W\n.temp 25\n.control\nop\nprint v(out)\nquit\n.endc\n.end\n')
 try:r=subprocess.run(['ngspice','-b','check.cir'],cwd=d,capture_output=True,text=True,check=True)
 except FileNotFoundError:sys.exit('Install ngspice and add it to PATH.')
 m=re.search(r'v\(out\)\s*=\s*([-+0-9.eE]+)',r.stdout,re.I)
 if not m:sys.exit('No diode voltage found; inspect ngspice output: '+r.stderr+'\n'+r.stdout)
 v=float(m.group(1));print(f'Model V_f at 1 mA, 25 C: {v:.6f} V; manufacturer maximum: 0.715 V')
 if not 0<v<=.715:sys.exit('One-point datasheet bound not met.')
 print('PASS: recorded file identity and one datasheet bound only; model accuracy, package, transient and all other parameters remain unverified.')
