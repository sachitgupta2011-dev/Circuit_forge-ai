/* Fresh worker per run: keeps simulations isolated and permits hard timeout. */
import {Simulation} from './vendor/eecircuit-engine-1.9.0.mjs';
onmessage=async ({data})=>{
 try{
  const sim=new Simulation();
  await sim.start();sim.setNetList(data.deck);const result=await sim.runSim();
  const info=sim.getInfo(),errors=sim.getError();
  postMessage({ok:!errors.some(x=>!/(^|\s)(note|warning):/i.test(x)),result,info,errors});
 }catch(e){postMessage({ok:false,errors:[String(e&&e.message||e)]});}
};
