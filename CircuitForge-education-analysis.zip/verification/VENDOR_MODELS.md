# Manufacturer model evidence (limited)

The ngspice WebAssembly panel can insert a local model file as text. It does not automatically certify its origin, license, accuracy, pin mapping, or PSpice compatibility. Download only from trusted sources, verify hashes and revisions, and inspect model limitations.

## Tested files

1. Diodes Incorporated 1N4148W switching diode. Product page: https://www.diodes.com/part/view/1N4148W ; model: https://www.diodes.com/spice/download/1589/1N4148W.spice.txt . SHA-256 of the recorded download: `eac112ab3b235eb9f54916f7f9d793ba15091a1fb6988e4eef5652aad393437a`. At 27 °C and 1 mA, browser ngspice 45.2 produced 0.614359 V; at 25 °C, native ngspice 44.2 produced 0.618177 V, below the manufacturer's 0.715 V maximum at 1 mA. These are not identical temperature comparisons.
2. onsemi 2N7002K MOSFET. Model: https://www.onsemi.com/pub/Collateral/2N7002K.LIB.TXT . SHA-256 of the recorded download: `274596f914278f7eaeae6b80a7a7b78753bbce82aba606742e0a3404c3deaeec`. With 5 V supply, 1 kΩ load, 2 V gate, 0 V source, ngspice 45.2 WebAssembly produced V(d) = 0.028103711 V, agreeing with native ngspice 44.2 (0.02810371 V) for the same supplied subcircuit and test. This establishes tool agreement for a single operating point, not agreement with measured hardware.

3. Diodes Incorporated MMBT3904 BJT. Model: https://www.diodes.com/spice/download/2869/MMBT3904.spice.txt ; product page: https://www.diodes.com/part/view/MMBT3904 . SHA-256: `49c344a0aaa461869b9a6f7a67e8afc0afbb0050a6b4f7e19e44025b076a6d2d`. At 27 °C, 5 V supply, 1 kΩ collector resistor and 0.65 V base, browser ngspice gave V(c) = 2.155872965 V and native ngspice 44.2 gave 2.155873 V. One point of cross-tool agreement only, not hardware validation.

Manufacturer model files are not redistributed in this package. To reproduce the browser checks after installing test dependencies and downloading all three files directly:

```
cd tests
node vendor-wasm-check.cjs /path/to/1N4148W.spice.txt /path/to/2N7002K.LIB.TXT /path/to/MMBT3904.spice.txt
```

The recorded file hashes may change with new manufacturer revisions; a mismatch stops the test. Review the current file and its terms rather than blindly overriding the check. Full sweeps over voltage, current, frequency, temperature and process corners against datasheets and physical measurements are not performed; there is no general vendor-model verification claim.

## Expanded cross-engine DC sweeps

Reproducible `tests/vendor-sweep-check.cjs` compares browser ngspice 45.2 with native ngspice 44.2, using the same hash-checked manufacturer file and deck, at 0, 27 and 70 °C. The diode current was swept from 0.1–1 mA (10 points per temperature); MOSFET gate voltage 1–3 V (11 points per temperature) with a 5 V supply and 1 kΩ load; BJT base voltage 0.55–0.75 V (11 points per temperature) with a 5 V supply and 1 kΩ load. All **96 points** agreed to within 0.002 V, with the largest observed difference 4.533e-7 V (native printed values are rounded). This is cross-version consistency, not independent physics validation: both use ngspice and the same model. It does not validate process corners, AC, transient behavior, safe operating area, physical measurements or all vendor models. Temperatures are simulator inputs, not evidence the model accurately represents temperature behavior.

After independently obtaining the three files listed above and installing native ngspice and test dependencies:

```
cd tests
node vendor-sweep-check.cjs /path/to/1N4148W.spice.txt /path/to/2N7002K.LIB.TXT /path/to/MMBT3904.spice.txt
```
