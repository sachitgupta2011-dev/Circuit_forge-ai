# Validation and known limits

## AC and Bode
The SPICE Lab now allows selecting an output and a reference node for the complex transfer V(out)/V(ref), or absolute node voltage in dBV. Phase is wrapped to ±180°. A zero reference is rejected. AC independent current source phase/polarity and VCCS stamping were corrected; a non-converged DC operating point is reported rather than silently used. The engine remains an educational subset, not a general SPICE implementation. For example, many vendor model parameters, device parasitics, and directives are unsupported; do not use it to certify a nonlinear, high-frequency, safety-critical or production design.

An RC low-pass at 1 kHz gives -3.0103 dB and -45 degrees; 21 complex node voltages agree with ngspice 44.2 within 1.21e-9 V on this fixture. Additional current-source phase and VCCS examples are checked against analytical results. See numerical-results.txt.

## Transients
Three passive pulse-driven RC, RL, and RLC fixtures were compared to ngspice 44.2, interpolating ngspice's adaptive samples onto the browser's fixed timestep. The maximum differences were 0.02485 V, 0.02486 V and 0.06299 V respectively on a 5 V input. Differences include fixed-step startup and integration behavior. These are limited test cases, not full transient validation. Nonlinear and stiff circuits, switching events, initial conditions and timestep convergence need further independent validation.

## Manufacturer models
The model registry now links the manufacturer product page for Diodes Incorporated 1N4148W, which links a manufacturer SPICE file:
https://www.diodes.com/part/view/1N4148W
https://www.diodes.com/spice/download/1589/1N4148W.spice.txt
The vendor file was not bundled or represented as a verified working model: the browser engine does not implement all its parameters (including diode parasitics), and no pin-by-pin, revision, license or physical-device validation was completed. Use the vendor file in a compatible full SPICE tool under its terms; inspect the source and review the exact part. Other catalogue placeholders are not vendor-verified models either.

## Independent Gerber/drill viewer
The included example board is a starter project with one added front-copper track and one via. Gerbv 2.10.0 parsed and rendered each of its front/back copper, solder mask, top silkscreen, outline and drill files, with no CLI errors. A combined viewer rendering and exact exported files are in gerber-fixture/. This demonstrates parser acceptance for ONE example only; it is not a geometric audit, DRC, or manufacturing approval. PCB tracks in the separate Platform planner are not included. The exporter explicitly does not rasterize copper pours or inner planes. Empty and 4-layer boards, slots, footprints, solder mask expansion, drills, plated/non-plated classification, and all manufacturing constraints require independent assessment in KiCad/CAM and by the fabricator before ordering.

## Re-run tests
Browser tests require Node.js, Python 3 and Playwright/Chromium:
  cd tests
  npm install
  npx playwright install chromium
  npm test
They test all 10 built-in Learn templates for load and DC convergence, Learn revision restore, 12 pre-existing SPICE regressions, RC/RL/RLC analytical sample points, AC phase and magnitude, AC current/VCCS, Bode UI and a Monte Carlo run. They do not cover all combinations, UI actions, robotics, exports, or all simulation features.

For independent checks install ngspice and gerbv, then run:
  python3 tests/independent-checks.py
This compares the included captured browser data with fresh ngspice results and asks Gerbv to render each saved export fixture. It does not recapture the browser outputs or verify a new design. To validate current changes independently, recapture equivalent waveforms and compare again. All test results are regression evidence, not proof of accuracy or hardware safety.

## Additional engineering reliability pass
- Corrected DC and transient independent-current-source polarity and PNP/PMOS Jacobian polarity. DC and transient report non-convergence instead of claiming success. Added parenthesized/continued model parsing with warnings for ignored parameters; external .include/.lib files are rejected instead of silently ignored. These fixes do **not** establish full SPICE compatibility or verify manufacturer device models.
- Four synthetic DC examples (NPN, PNP, NMOS and PMOS) were compared to ngspice. Collector/drain voltage deltas were about 0.000160 V, 0.000160 V, 4.95e-9 V, and 5e-11 V respectively. These are simplified examples and do not validate nonlinear dynamics, parasitics, device corners, saturation, body effects or real vendor models.
- Added independent AC sweeps for RC high-pass (81 points, max complex-voltage error 9.19e-10 V) and series RLC resonance (91 points, 5.03e-10 V). Comparisons use the saved browser fixtures, ngspice 44.2, and rounded ngspice output. They are not a broad solver qualification.
- The inherited solid-polygon pour was unsafe: it did not clear unrelated traces and pads. It is now omitted from two-layer Gerber files. Direct multilayer Gerber/release export is blocked because inner routing and clearance-aware fills are not ready. Use editable KiCad drafts only with external review and do not infer fabrication readiness. The example Gerber fixture was regenerated without the unsafe fill. Parser acceptance in Gerbv is not a connectivity or clearance check.
- Monte Carlo/worst-case refuses modeled nonlinear decks rather than silently dropping models. The sensitivity-based corner estimator is explicitly an approximation, not a guaranteed extreme.
- Collaboration and community remain local prototypes. Reliable sharing requires a separately deployed authenticated backend, transport security, authorization, durable storage/backups, conflict resolution, abuse prevention, and multi-client testing. No live collaboration service is supplied by this package.

## Further regression and geometry updates
- Fixed engineering suffix parsing for independent voltage/current DC and AC values and corrected SIN parameter order (frequency before delay), including phase and damping. An RC sinusoidal transient compared with ngspice had a 0.009045 V maximum error for a 1 V input at 2 µs steps (ngspice waveform interpolated). This is one test, not a general accuracy guarantee.
- Added 100 resistor-divider cases and checks for source units, SIN, via-to-trace clearance, pad-to-pad clearance, board-edge clearance, opposite-side SMD pads, and integration into PCB DRC. Added a conservative supplemental audit for via–trace, via–pad, via–via, pad–pad and trace/via-to-edge spacing. Square pads use a conservative bounding radius; rounded/irregular shapes, slots, plane clearances, and all fabricator rules are not fully modeled. Plane connectivity is no longer assumed for unimplemented inner fills. Continue to run a full independent KiCad DRC and CAM review.
- Added an optional local command-line ngspice runner in tools/. It does not connect ngspice to the website, bundle ngspice, or sandbox untrusted files. See tools/README.md.
- Manufacturer-source evidence: the Diodes Incorporated 1N4148W manufacturer-hosted file at https://www.diodes.com/spice/download/1589/1N4148W.spice.txt was retrieved and its SHA-256 was eac112ab3b235eb9f54916f7f9d793ba15091a1fb6988e4eef5652aad393437a. Using ngspice 44.2 at 25 °C, its 1 mA diode voltage was 0.618177 V, below the manufacturer's 0.715 V maximum at 1 mA (https://www.diodes.com/part/view/1N4148W). `tests/vendor-model-check.py` repeats this check on a separately downloaded, trusted file. This establishes provenance and one limited point only—not full verification, compatibility with the browser engine, or validation against physical devices. Model files are not bundled. Also linked onsemi's manufacturer-hosted 2N7002K PSpice file as a reference; its compatibility and accuracy were not verified.

## WebAssembly ngspice and team snapshot prototype
The new separate ngspice workspace bundles EEcircuit-engine 1.9.0 (runtime reports ngspice 45.2). Browser tests ran RC AC and transient cases, synthetic diode/BJT/MOS operating points, and malformed-input rejection. The browser worker was also checked after an initial online load with the browser offline. The ngspice workspace accepts inline models; manufacturer model identity, accuracy, license, pinout, PSpice compatibility and every model/circuit type are not verified by these checks. External model file includes are blocked in the browser panel; the insert button copies local model text inline for review. The previous simplified solver remains separately available.

The Node team server passed automated authentication and Origin rejection, two-client snapshot broadcast, stale-write conflict, persistence across restart, and a two-browser UI create/join/publish/apply flow. It is an unaudited shared-token prototype with explicit snapshots rather than simultaneous editing. See backend/README.md for TLS, deployment, testing, backup and security limitations.

The PCB still lacks validated inner-layer routing and clearance-aware polygon fills. Multilayer Gerber export remains blocked. Existing two-layer geometry checks are conservative and incomplete. None of these checks replaces KiCad ERC/DRC, independent CAM review, model qualification, or hardware testing.

## KiCad handoff and manufacturer-model cross-checks
An external KiCad-based route is now included at `tools/kicad_release.py`. It copies a board, refills KiCad zones, runs KiCad DRC with fail-closed handling, and creates multilayer Gerber and separated PTH/NPTH drill drafts only after a clean report. In KiCad 9.0.2, an empty four-layer fixture passed and output layers were parsed by Gerbv; the CircuitForge starter four-layer fixture failed with DRC and unconnected findings and produced no Gerbers. Fixture reports and `tests/kicad-check.py` are included. The passing empty board does not validate complex routing, manufacturer footprints, stackups, copper fills, or real boards. Complete and inspect the design manually in KiCad, run ERC/DRC using fabricator-specific rules, and independently inspect CAM outputs. The browser's direct multilayer export remains blocked, and its planner routes are separate from the exported KiCad draft.

Three vendor-supplied files (1N4148W diode, 2N7002K MOSFET and MMBT3904 BJT) were hash-checked and compared across 96 DC sweep points and three temperatures between browser and native ngspice. See `VENDOR_MODELS.md` and its reproducible optional tests. Files are not bundled; this is not physical or general model validation.

The team backend adds immediate logout connection revocation and in-memory/session/room connection quotas, with regression coverage. It now uses separately provisioned accounts and room-owner-managed access, with local negative-access tests. It has not been independently security audited or load-tested. It is not safe to claim as an open public service.
