DRAFT ONLY. Copper pours are omitted because clearance-aware fill is not implemented. Refill zones and run ERC/DRC in KiCad; inspect all layers and drills in CAM before fabrication.
