CircuitForge education and analysis package

Run locally: in this folder, run `python3 -m http.server 8000`, then visit http://localhost:8000/ in a browser. To install and use offline on other devices, serve the folder over HTTPS. Open it once online first so the service worker can cache the app. Opening index.html directly works for many features but cannot install the PWA or register its service worker. Keep the files together.

The Learn portal contains guided circuits and an offline, rule-based tutor (not a local large language model). Version history in Learn is stored in this browser; export important work as JSON because clearing browser data removes local snapshots. The language selector translates part of the interface, not all educational content. Monte Carlo and SPICE use simplified educational models. PCB fabrication outputs are drafts: independently check footprints, ERC/DRC, drill files and Gerbers using professional tools and test hardware before manufacturing. Collaboration or external AI services need separate configuration and network access.

Restored learning material: the 10 built-in guided lessons load circuit templates; six extra topics are concept guides only and do not claim to load circuits. In Platform Studio, the Gerber shortcut opens the main PCB workspace's Quality & Handoff export; the separate multilayer planner's tracks are not transferred. Its former placeholder export did not generate a working ZIP and is not used.

See verification/VALIDATION.md for numerical results, the independent Gerbv example, exact scope, and instructions to run tests. The Bode plot can display V(output)/V(reference); use the Reference selector after running an AC sweep. The model registry includes a link to a manufacturer-supplied diode model, but that model is not certified compatible with this simplified solver.

Engineering reliability update: unsafe solid copper pours were removed and multilayer Gerber exports are blocked until routing and clearance-aware fills are implemented. Two-layer drafts omit copper pours. Independently review all PCB exports before fabrication. The added nonlinear checks use synthetic component models, not verified manufacturer device models. Collaboration and community features still require a separate service; no hosted backend is included.

Latest update: supplemental PCB spacing checks and expanded regression coverage were added; the included optional tools/run_ngspice.py runs trusted decks using a separately installed ngspice. Verified manufacturer-model support, exhaustive simulation coverage, production multilayer routing and manufacturing-grade DRC are still incomplete. Review verification/VALIDATION.md before relying on any result.

New: `ngspice WASM` opens a separate real ngspice WebAssembly netlist workspace in the AI Studio; it supports local model text insertion, simulation logs, and CSV download. Serve the folder over localhost or HTTPS; first installation caches the approximately 20 MB engine for offline use. One analysis per deck is recommended. Existing simplified SPICE tools remain separate.

New: `Team workspace` connects to the optional self-hosted backend for explicit, conflict-checked shared project snapshots. See backend/README.md. It is a trusted-team prototype, not simultaneous editing or a security-audited public service.

Multilayer routing, clearance-aware fills, full model qualification, and comprehensive all-circuit testing are NOT complete. Multilayer Gerber export remains blocked, and external KiCad/CAM review remains necessary.

Further update: a separate KiCad-based multilayer Gerber/drill draft workflow is available in tools/kicad_release.py, which refills and requires a clean KiCad DRC. It requires KiCad and a manually completed PCB with fabricator-specific rules. Direct browser multilayer export is still blocked; planner tracks are not transferred. Three manufacturer-sourced model files have been checked across DC sweeps and temperatures (see verification/VENDOR_MODELS.md); this does not verify models generally. The team server remains an unaudited trusted-team prototype, not a safe public service.

Current update: Studio's Workbench offers tool search (Alt+K), locally stored self-checklists for learning/circuit/PCB/robot workflows, and ideal-circuit calculators. See README.md for limits. The Robotics Lab also includes a separate educational rover experiment. These additions do not resolve the independent PCB, model verification, hardware, or public backend limitations described above.

Latest backend update supersedes prior shared-token descriptions: locally provisioned individual accounts and owner-managed room membership are implemented and tested, but the backend remains unaudited; the identity gateway is untested; a separate experimental OIDC backend maps Keycloak subjects to separate app accounts. Legacy ownerless rooms are inaccessible. See backend/README.md. Browser PCB checks were expanded but remain incomplete; direct multilayer export remains blocked.

Latest OIDC-mode details supersede older gateway descriptions: see deployment/README.md for the tested mock-token mapping, owner/viewer/editor permissions, and the untested real gateway/realm stack. Encryption requires an operator-provisioned encrypted volume; public deployment still requires independent review.

Most recent identity update: a disposable real Docker stack was tested for registration, OTP, email capture, viewer authorization, WebSocket traffic, logout and OTP-protected password reset. A test OIDC broker was also checked. Production SMTP, Google/GitHub and independent security review remain outstanding; see deployment/README.md.
