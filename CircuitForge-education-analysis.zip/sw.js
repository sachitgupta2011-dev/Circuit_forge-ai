const CACHE = 'circuitforge-shell-v12';
const SHELL = ['./index.html', './manifest.webmanifest', './icon-192.png', './icon-512.png', './spice-worker.js', './spice-integration.js', './collab-ui.js', './pcb-release-ui.js', './robotics-advanced.js', './workbench-plus.js', './pcb-rules-ui.js', './vendor/eecircuit-engine-1.9.0.mjs'];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())));
self.addEventListener('activate', event => event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith('circuitforge-shell-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())));
self.addEventListener('fetch', event => {
  const req = event.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== self.location.origin) return;
  if (req.mode === 'navigate') {
    event.respondWith(fetch(req).catch(async () => (await caches.match('./index.html')) || Response.error()));
  } else {
    event.respondWith(caches.match(req).then(hit => hit || fetch(req)));
  }
});
