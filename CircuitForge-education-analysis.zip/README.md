
### Generic KiCad rule starting point

For a downloaded `.kicad_pcb` draft, run `python3 tools/setup_generic_kicad.py /path/to/board.kicad_pcb` to create editable matching project and custom rule files without overwriting existing ones. The example baseline uses 0.25 mm minimum track/clearance and 0.30 mm minimum hole; review all settings against your fabricator and design. Then run the KiCad release helper described in `tools/README.md`. This is a separate KiCad workflow, not complete in-browser multilayer routing or fabrication sign-off. Planner-only routes are not transferred; inspect all geometry, connectivity, footprints and zones in KiCad.

A **staging-tested identity gateway template** is in `deployment/README.md`; it does not make the unaudited backend safe for public or multi-tenant use.

### Advanced rover experiments

Open Studio → Robots → **Advanced rover experiments**. Click the map to set a goal, tune speed, wheelbase and heading PID gains, then run, pause, single-step or reset. Download the recorded trajectory and telemetry as CSV. The front ray and collision checks use a fixed rectangular obstacle map. A simple motor response lag, bounded controller and illustrative battery indicator are included. There is no path planner in this experiment: a goal behind an obstacle can remain unreachable. A maximum of 12,000 samples is retained per run. This independent educational model does not simulate your assembly or run its firmware and cannot establish physical safety or battery runtime. The existing Robotics Lab features remain available separately.

The hardware checklist is a manual starting point, not a hardware connection, driver, pinout verifier, or firmware uploader. The existing assembly firmware exports must be reviewed for the specific board and driver; always use a physical emergency stop and a supervised low-power bench test.

Run `cd tests && npm install && npx playwright install chromium && npm test` for the browser regression suite including experiment tests. These tests verify a clear-goal run, a blocked obstacle case and UI behavior, not physics accuracy against a real robot.

### Workbench: search, guided workflows and calculators

In Studio, select **Workbench** in the top bar or press Alt+K. Search shortcuts to the existing editors, ngspice, PCB checks, learning portal and robotics experiment. Guided checklists cover circuits, PCB handoff, robotics and learning; checkmarks are stored in this browser only and are not associated with a particular project. They are self-reported, not evidence that any check passed. Use Clear these checkmarks to reset each guide.

The offline calculators cover ideal DC Ohm's law, LED series resistance (including an E12 suggestion), unloaded dividers and first-order RC cutoff. They are estimates: use real component tolerances, loads, thermal margins and datasheets, and validate important designs independently. These usability additions do not make the PCB DRC complete, connect the robotics simulator to hardware, or make the collaboration backend safe for public deployment.

### Latest engineering work

The collaboration prototype now uses separately provisioned user accounts and owner-managed room membership instead of the shared team token. See `backend/README.md`, including the deliberate incompatibility with older ownerless rooms. It remains unaudited and unsuitable for unrestricted public deployment. The separate OIDC backend maps verified Keycloak subjects to app accounts; a disposable real-stack staging test now covers selected authentication and collaboration paths.

The PCB toolbar has **Extra DRC rules** for optional track width, drill diameter, via annular ring and hole-to-hole gap checks; pad-edge checking was also added. Example values are not a fabricator specification. Browser DRC remains incomplete and conservative, and direct multilayer Gerber export remains blocked. Complete the board and check it in KiCad as documented.

Manufacturer model coverage now includes 96 cross-engine DC sweep points at three temperatures across the diode, MOSFET and BJT. See `verification/VENDOR_MODELS.md`; this is not hardware validation or general model certification.

### Experimental Keycloak identity mode

A separate OIDC-backed collaboration server and revised Compose staging template now map a verified Keycloak subject to an app account, with owner/viewer/editor access and local audit-attempt records. A realm template requests registration, verified email, password reset and default OTP enrollment. A disposable real Docker stack has been tested with Keycloak, OAuth2 Proxy, Caddy, PostgreSQL and a local SMTP capture server; see `deployment/README.md` for coverage and exclusions. Configure and verify SMTP, Google/GitHub, MFA and an encrypted host volume as described in `deployment/README.md`; encryption is not automatically provisioned. The system remains unaudited and is not approved for public or multi-tenant deployment.
